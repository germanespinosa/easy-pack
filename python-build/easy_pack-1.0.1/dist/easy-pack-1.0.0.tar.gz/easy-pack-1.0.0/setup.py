from setuptools import setup

setup(name='easy-pack',description='easy packing!',author='german espinosa',author_email='germanespinosa@gmail.com',packages=['easy_pack'],install_requires=['twine'],license='MIT',version='1.0.0',zip_safe=False)
